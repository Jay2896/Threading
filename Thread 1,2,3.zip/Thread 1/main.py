import time
import threading

def print_hi1(name):
    print(f'{name}print_hi1 started')
    time.sleep(10)
    print(f'{name}print_hi1 ended')

def print_hi2(name):
    print(f'{name}print_hi2 started')
    time.sleep(10)
    print(f'{name}print_hi2 ended')

def print_hi3(name):
    print(f'{name}print_hi3 started')
    time.sleep(10)
    print(f'{name}print_hi3 ended')

if __name__ == '__main__':
    print('Welcome to Thread Program')
    t1 = threading.Thread(target=print_hi1, args=('Pycharm ',))
    t1.start()
    t2 = threading.Thread(target=print_hi2, args=('Pycharm ',))
    t2.start()
    t3 = threading.Thread(target=print_hi3, args=('Pycharm ',))
    t3.start()
    t1.join()
    t2.join()
    t3.join()

    print('Run Successful')