import concurrent.futures
import time

def my_func(name):
    print(f' my_func started with {name}')
    time.sleep(10)
    print(f' my_func ended with {name}')

if __name__ == '__main__':
    print('main begins')
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
        ex.map(my_func, ['moe', 'larry', 'curly'])
    print('main ended')